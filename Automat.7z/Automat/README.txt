Kleiner feiner Automaten für die Programmier Sprache: Small Basic V1.2

Ist einer der kleinen Schritte um Programmieren zu lernen.

Made by: Ichkanneshalt / Nia
Find me here:https://ebio.gg/Nia